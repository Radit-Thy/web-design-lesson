document.getElementById("contact-form").addEventListener("submit", function(event) {
    event.preventDefault();
  
    // Validate the form data
  
    // If the form data is valid, submit the form
    this.submit();
  });
  